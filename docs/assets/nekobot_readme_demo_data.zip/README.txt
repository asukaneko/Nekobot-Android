NekoBot Android README 截图演示数据

导入入口：
  更多 → 本地数据库 → 从文件导入

建议显示名称：
  README 演示数据

内容：
  5 个虚构角色
  10 个示例会话
  120 条示例消息
  3 本世界书
  5 条角色记忆

安全说明：
  所有人物、对话与凭据均为虚构演示内容。
  数据库中的 DEMO_KEY_NOT_USABLE 不是有效 API Key。
